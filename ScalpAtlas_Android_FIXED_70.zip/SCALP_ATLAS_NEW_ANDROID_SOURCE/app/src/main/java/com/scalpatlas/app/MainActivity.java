package com.scalpatlas.app;

import android.app.Activity;
import android.Manifest;
import android.content.ClipData;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.content.pm.ResolveInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class MainActivity extends Activity {
    private static final int CAMERA_REQUEST = 1001;
    private static final int GALLERY_REQUEST = 1002;
    private static final int MAX_IMAGE_SIDE = 1800;
    private static final int WEB_CAMERA_PERMISSION_REQUEST = 2001;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraUri;
    private File cameraFile;
    private boolean nativeRequestInProgress = false;
    private PermissionRequest pendingWebCameraRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(5, 11, 18));
        window.setNavigationBarColor(Color.rgb(1, 4, 9));

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(true);

        webView.addJavascriptInterface(new AndroidBridge(), "ScalpAtlasAndroid");
        webView.setWebViewClient(new WebViewClient());

        // Fallback pentru dispozitive/WebView care folosesc în continuare input type=file.
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> filePath,
                    FileChooserParams fileChooserParams) {
                cancelPendingFileRequest();
                filePathCallback = filePath;
                if (fileChooserParams != null && fileChooserParams.isCaptureEnabled()) {
                    return openCamera(false);
                }
                return openGallery(false);
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean asksForCamera = false;
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                            asksForCamera = true;
                            break;
                        }
                    }

                    if (!asksForCamera) {
                        request.deny();
                        return;
                    }

                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA)
                            == PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        if (pendingWebCameraRequest != null) pendingWebCameraRequest.deny();
                        pendingWebCameraRequest = request;
                        ActivityCompat.requestPermissions(
                                MainActivity.this,
                                new String[]{Manifest.permission.CAMERA},
                                WEB_CAMERA_PERMISSION_REQUEST
                        );
                    }
                });
            }
        });

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    public final class AndroidBridge {
        @JavascriptInterface
        public void openCamera() {
            runOnUiThread(() -> {
                nativeRequestInProgress = true;
                MainActivity.this.openCamera(true);
            });
        }

        @JavascriptInterface
        public boolean isNativeApp() {
            return true;
        }

        @JavascriptInterface
        public void openGallery() {
            runOnUiThread(() -> {
                nativeRequestInProgress = true;
                MainActivity.this.openGallery(true);
            });
        }
    }

    private boolean openCamera(boolean nativeRequest) {
        if (!nativeRequest) nativeRequestInProgress = false;
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        try {
            cameraFile = createCameraFile();
            cameraUri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".fileprovider",
                    cameraFile
            );
        } catch (Exception e) {
            cleanupCameraFile();
            finishFileRequest(null);
            nativeError("Nu pot pregăti fotografia pentru cameră.");
            nativeRequestInProgress = false;
            return true;
        }

        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
        cameraIntent.setClipData(ClipData.newRawUri("Scalp Atlas camera output", cameraUri));
        cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);

        List<ResolveInfo> cameraApps = getPackageManager().queryIntentActivities(cameraIntent, 0);
        for (ResolveInfo info : cameraApps) {
            grantUriPermission(
                    info.activityInfo.packageName,
                    cameraUri,
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION
            );
        }

        try {
            startActivityForResult(cameraIntent, CAMERA_REQUEST);
        } catch (ActivityNotFoundException e) {
            revokeCameraUriPermission();
            cleanupCameraFile();
            finishFileRequest(null);
            nativeError("Nu am găsit o aplicație Cameră pe telefon.");
            nativeRequestInProgress = false;
        } catch (Exception e) {
            revokeCameraUriPermission();
            cleanupCameraFile();
            finishFileRequest(null);
            nativeError("Camera nu poate fi deschisă.");
            nativeRequestInProgress = false;
        }
        return true;
    }

    private File createCameraFile() throws IOException {
        File directory = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (directory == null) throw new IOException("Pictures directory unavailable");
        if (!directory.exists() && !directory.mkdirs()) throw new IOException("Cannot create Pictures directory");
        return File.createTempFile("scalp_atlas_", ".jpg", directory);
    }

    private boolean openGallery(boolean nativeRequest) {
        if (!nativeRequest) nativeRequestInProgress = false;
        Intent galleryIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        galleryIntent.addCategory(Intent.CATEGORY_OPENABLE);
        galleryIntent.setType("image/*");
        galleryIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(galleryIntent, GALLERY_REQUEST);
        } catch (Exception e) {
            finishFileRequest(null);
            nativeError("Galeria nu poate fi deschisă.");
            nativeRequestInProgress = false;
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CAMERA_REQUEST) {
            boolean hasFullImage = cameraUri != null && cameraFile != null && cameraFile.exists() && cameraFile.length() > 0;
            Bitmap thumbnail = null;

            // Unele aplicații Cameră (inclusiv anumite implementări Android 14) pot
            // scrie fotografia, dar pot întoarce RESULT_CANCELED. Acceptăm fișierul
            // dacă există și are conținut, indiferent de codul rezultatului.
            if (!hasFullImage && data != null && data.getExtras() != null) {
                Object extra = data.getExtras().get("data");
                if (extra instanceof Bitmap) thumbnail = (Bitmap) extra;
            }

            boolean hasAnyImage = hasFullImage || thumbnail != null;
            revokeCameraUriPermission();

            if (hasAnyImage) {
                if (nativeRequestInProgress) {
                    if (hasFullImage) sendImageToWeb(cameraUri, "camera");
                    else sendBitmapToWeb(thumbnail, "camera");
                    cleanupCameraFile();
                } else if (hasFullImage) {
                    // WebView citește URI-ul după callback; nu ștergem fișierul imediat.
                    finishFileRequest(new Uri[]{cameraUri});
                    cameraFile = null;
                    cameraUri = null;
                } else {
                    try {
                        Uri fallbackUri = saveBitmapForFileChooser(thumbnail);
                        finishFileRequest(new Uri[]{fallbackUri});
                    } catch (Exception e) {
                        finishFileRequest(null);
                    }
                    cleanupCameraFile();
                }
            } else {
                if (nativeRequestInProgress && resultCode != RESULT_CANCELED) {
                    nativeError("Fotografia nu a fost salvată de cameră.");
                }
                finishFileRequest(null);
                cleanupCameraFile();
            }

            nativeRequestInProgress = false;
            return;
        }

        if (requestCode == GALLERY_REQUEST) {
            Uri selected = null;
            if (resultCode == RESULT_OK && data != null) selected = data.getData();
            if (selected != null) {
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                try {
                    getContentResolver().takePersistableUriPermission(selected, flags);
                } catch (Exception ignored) { }

                if (nativeRequestInProgress) {
                    sendImageToWeb(selected, "gallery");
                } else {
                    finishFileRequest(new Uri[]{selected});
                }
            } else {
                finishFileRequest(null);
            }
            nativeRequestInProgress = false;
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == WEB_CAMERA_PERMISSION_REQUEST && pendingWebCameraRequest != null) {
            PermissionRequest request = pendingWebCameraRequest;
            pendingWebCameraRequest = null;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            } else {
                request.deny();
                nativeError("Permisiunea pentru cameră este necesară pentru fotografiere.");
            }
        }
    }

    private void sendImageToWeb(Uri uri, String source) {
        try {
            String dataUrl = imageUriToDataUrl(uri);
            String js = "window.receiveNativeImage(" + JSONObject.quote(dataUrl) + "," + JSONObject.quote(source) + ");";
            webView.evaluateJavascript(js, null);
        } catch (Exception e) {
            nativeError("Fotografia a fost făcută, dar nu a putut fi încărcată în Scalp Atlas.");
        }
    }

    private void sendBitmapToWeb(Bitmap bitmap, String source) {
        if (bitmap == null) {
            nativeError("Camera nu a returnat o fotografie validă.");
            return;
        }
        try {
            String dataUrl = bitmapToDataUrl(bitmap);
            String js = "window.receiveNativeImage(" + JSONObject.quote(dataUrl) + "," + JSONObject.quote(source) + ");";
            webView.evaluateJavascript(js, null);
        } catch (Exception e) {
            nativeError("Fotografia a fost făcută, dar nu a putut fi încărcată în Scalp Atlas.");
        }
    }

    private Uri saveBitmapForFileChooser(Bitmap bitmap) throws IOException {
        File file = createCameraFile();
        try (java.io.FileOutputStream out = new java.io.FileOutputStream(file)) {
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)) {
                throw new IOException("Cannot write camera thumbnail");
            }
        }
        return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
    }

    private String bitmapToDataUrl(Bitmap bitmap) throws IOException {
        Bitmap working = bitmap;
        int width = working.getWidth();
        int height = working.getHeight();
        int maxSide = Math.max(width, height);
        if (maxSide > MAX_IMAGE_SIDE) {
            float scale = MAX_IMAGE_SIDE / (float) maxSide;
            int newWidth = Math.max(1, Math.round(width * scale));
            int newHeight = Math.max(1, Math.round(height * scale));
            working = Bitmap.createScaledBitmap(working, newWidth, newHeight, true);
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        working.compress(Bitmap.CompressFormat.JPEG, 88, out);
        if (working != bitmap) working.recycle();
        String base64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        return "data:image/jpeg;base64," + base64;
    }

    private String imageUriToDataUrl(Uri uri) throws IOException {
        Bitmap bitmap;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IOException("Cannot open image");
            bitmap = BitmapFactory.decodeStream(in);
        }
        if (bitmap == null) throw new IOException("Cannot decode image");

        String dataUrl = bitmapToDataUrl(bitmap);
        bitmap.recycle();
        return dataUrl;
    }

    private void nativeError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        if (webView != null) {
            webView.evaluateJavascript("window.nativeImageError(" + JSONObject.quote(message) + ");", null);
        }
    }

    private void revokeCameraUriPermission() {
        if (cameraUri != null) {
            try {
                revokeUriPermission(cameraUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) { }
        }
    }

    private void cleanupCameraFile() {
        if (cameraFile != null && cameraFile.exists()) {
            //noinspection ResultOfMethodCallIgnored
            cameraFile.delete();
        }
        cameraFile = null;
        cameraUri = null;
    }

    private void cancelPendingFileRequest() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        revokeCameraUriPermission();
        cleanupCameraFile();
    }

    private void finishFileRequest(Uri[] result) {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        if (isFinishing()) cancelPendingFileRequest();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
