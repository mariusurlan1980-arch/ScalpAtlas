# Add project-specific R8 rules here.
