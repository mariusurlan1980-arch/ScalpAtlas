# Scalp Atlas — Android test build v0.4

Proiect Android nativ care încarcă interfața Scalp Atlas din `app/src/main/assets/index.html` într-un WebView.

## Reparat în această versiune
- corectați operatorii JavaScript invalizi `££` -> `&&` care opreau complet analiza;
- Camera și Galeria sunt acum două acțiuni separate;
- fotografia făcută cu camera este transmisă în WebView pentru analiză;
- fotografia aleasă din galerie este transmisă în același flux de analiză;
- timeframe complet: M1, M2, M3, M5, M10, M15, M30, H1;
- atlas local: 70 modele;
- eliminate fișierele Gradle Kotlin DSL duplicate pentru a evita configurarea ambiguă;
- Gradle/CI aliniate la 8.9 și Android Gradle Plugin 8.7.3;
- versionCode 4 / versionName `0.4-test-camera-gallery-fixed`.

## Build APK
Workflow-ul `.github/workflows/build-apk.yml` produce `ScalpAtlas.apk` prin GitHub Actions.

Verificări locale efectuate asupra acestei arhive: sintaxa JavaScript este validă cu Node.js, XML-urile Android sunt valide, iar atlasul conține 70 de intrări.
