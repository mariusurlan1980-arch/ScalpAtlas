SCALP ATLAS New Core 1.1 Premium
Android source with native camera/gallery bridge.
Atlas library: 70 named scalping patterns.
minSdk 24, targetSdk 35.
Includes 5 free analyses and the Premium screen.
Confirmed monthly price: EUR 19.99. Annual price is not yet confirmed.
