# Scalp Atlas — Android test build

Proiect Android nativ care încarcă interfața Scalp Atlas din `app/src/main/assets/index.html` într-un WebView.

## Ce a fost reparat
- adăugat `MainActivity.java` (lipsea din proiectul anterior, deci build-ul nu putea produce aplicația corectă);
- camera/galeria sunt deschise prin selectorul Android;
- fotografia capturată este transmisă către pagina locală pentru analiză;
- 70 de modele sunt incluse în atlasul local;
- build-ul GitHub Actions produce `ScalpAtlas.apk`.

## Build
În GitHub Actions: `Build Scalp Atlas APK` → `Run workflow`.
Artifactul rezultat: `ScalpAtlas-APK` → `ScalpAtlas.apk`.
